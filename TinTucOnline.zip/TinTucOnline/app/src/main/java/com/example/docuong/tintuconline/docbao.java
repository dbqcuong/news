package com.example.docuong.tintuconline;

/**
 * Created by Do Cuong on 08/03/2018.
 */

public class docbao {
    public String title;
    public String link;
    public String image;

    public docbao(String title, String link, String image) {
        this.title = title;
        this.link = link;
        this.image = image;
    }
}
