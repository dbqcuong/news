package com.example.docuong.tintuconline;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Do Cuong on 08/03/2018.
 */

public class Customadapter extends ArrayAdapter<docbao> {

        public Customadapter(Context context, int resource, List<docbao> items) {
            super(context, resource, items);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View view = convertView;
            if (view == null) {
                LayoutInflater inflater = LayoutInflater.from(getContext());
                view =  inflater.inflate(R.layout.dong_layout_listview, null);
            }
            docbao p = getItem(position);
            if (p != null) {
                // Anh xa + Gan gia tri
                TextView txttitle = (TextView) view.findViewById(R.id.textViewtitle);
                txttitle.setText(p.title);
                ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
                Picasso.with(getContext()).load(p.image).into(imageView);
            }
            return view;
        }
}
